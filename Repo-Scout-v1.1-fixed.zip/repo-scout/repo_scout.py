#!/usr/bin/env python3
"""
REPO SCOUT
Coded by Chrono

A Termux-friendly GitHub discovery CLI:
- Search GitHub users and rank username matches
- Search repositories/tools and rank by stars/popularity
- Inspect profiles and repositories
- Open GitHub URLs in the browser
- Optional GitHub token for higher API limits
"""

import json
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

API = "https://api.github.com"
TOKEN = os.getenv("GITHUB_TOKEN", "").strip()

# ---------- ANSI ----------
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
CYAN = "\033[96m"
BLUE = "\033[94m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
MAGENTA = "\033[95m"
WHITE = "\033[97m"
GRAY = "\033[90m"

def c(text, color):
    return f"{color}{text}{RESET}"

def clear():
    os.system("clear" if os.name != "nt" else "cls")

def line(ch="─", n=68):
    print(c(ch * n, CYAN))

def pause():
    input(c("\n[ENTER] ", GRAY))

def ask(prompt):
    try:
        return input(c(prompt, GREEN)).strip()
    except (KeyboardInterrupt, EOFError):
        print()
        return ""

def open_url(url):
    try:
        if shutil.which("termux-open"):
            subprocess.run(["termux-open", url], check=False)
        elif shutil.which("xdg-open"):
            subprocess.run(["xdg-open", url], check=False)
        else:
            print(c("Open this URL manually:", YELLOW))
            print(url)
    except Exception as e:
        print(c(f"Could not open browser: {e}", RED))

# ---------- UI ----------
def type_line(text, color=CYAN, delay=0.012):
    """Small terminal typing effect; skipped when output is redirected."""
    if not sys.stdout.isatty():
        print(text)
        return
    for ch in text:
        print(c(ch, color), end="", flush=True)
        time.sleep(delay)
    print()

def spinner(message="Connecting", duration=0.8):
    if not sys.stdout.isatty():
        return
    chars = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
    end = time.time() + duration
    i = 0
    while time.time() < end:
        print(f"\r{c(message, CYAN)} {c(chars[i % len(chars)], MAGENTA)}", end="", flush=True)
        time.sleep(0.07)
        i += 1
    print("\r" + " " * (len(message) + 4) + "\r", end="")

def progress(message="Loading", steps=16, delay=0.025):
    if not sys.stdout.isatty():
        return
    print(c(message, CYAN))
    for i in range(steps + 1):
        filled = "█" * i
        empty = "░" * (steps - i)
        pct = int(i / steps * 100)
        print(f"\r  {c(filled + empty, BLUE)} {pct:3d}%", end="", flush=True)
        time.sleep(delay)
    print()

def status_bar():
    token_state = c("TOKEN", GREEN) if TOKEN else c("PUBLIC", YELLOW)
    print(
        f"{c(' API ', BOLD + CYAN)} "
        f"{token_state}  "
        f"{c('•', GRAY)}  "
        f"{c('GitHub', WHITE)}  "
        f"{c('Termux/Linux', GRAY)}"
    )

def startup():
    clear()
    print()
    logo = [
        "██████╗ ███████╗██████╗  ██████╗     ███████╗ ██████╗ ██████╗ ██╗   ██╗████████╗",
        "██╔══██╗██╔════╝██╔══██╗██╔═══██╗    ██╔════╝██╔═══██╗██╔══██╗██║   ██║╚══██╔══╝",
        "██████╔╝█████╗  ██████╔╝██║   ██║    ███████╗██║   ██║██║  ██║██║   ██║   ██║",
        "██╔══██╗██╔══╝  ██╔═══╝ ██║   ██║    ╚════██║██║   ██║██║  ██║██║   ██║   ██║",
        "██║  ██║███████╗██║     ╚██████╔╝    ███████║╚██████╔╝██████╔╝╚██████╔╝   ██║",
        "╚═╝  ╚═╝╚══════╝╚═╝      ╚═════╝     ╚══════╝ ╚═════╝ ╚═════╝  ╚═════╝    ╚═╝",
    ]
    for row in logo:
        print(c(row, WHITE))
    print()
    type_line("                  GITHUB DISCOVERY & PROJECT INTELLIGENCE", MAGENTA, 0.006)
    type_line("                           Coded by Chrono  •  v1.0", CYAN, 0.008)
    print()
    line("═")
    status_bar()
    line("═")

def banner():
    clear()
    print()
    print(c("  ╔══════════════════════════════════════════════════════════════╗", CYAN))
    print(c("  ║                         REPO SCOUT                          ║", WHITE + BOLD))
    print(c("  ║              GitHub Discovery & Intelligence               ║", MAGENTA))
    print(c("  ╚══════════════════════════════════════════════════════════════╝", CYAN))
    print()
    status_bar()
    line("─")

def section(title, subtitle=""):
    print()
    print(c(f"  {title}", BOLD + WHITE))
    if subtitle:
        print(c(f"  {subtitle}", GRAY))
    line("─")

def result_header(title, query):
    print()
    print(c("╔" + "═" * 66 + "╗", CYAN))
    print(c(f"║ {title[:64]:<64} ║", WHITE + BOLD))
    print(c(f"║ {('Query: ' + query)[:64]:<64} ║", MAGENTA))
    print(c("╚" + "═" * 66 + "╝", CYAN))

# ---------- GitHub API ----------
# ---------- GitHub API ----------
def api_get(path, params=None):
    url = API + path
    if params:
        url += "?" + urllib.parse.urlencode(params)

    headers = {
        "Accept": "application/vnd.github+json",
        "User-Agent": "Repo-Scout/1.0",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    if TOKEN:
        headers["Authorization"] = f"Bearer {TOKEN}"

    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            body = json.loads(e.read().decode("utf-8"))
            message = body.get("message", str(e))
        except Exception:
            message = str(e)

        if e.code == 403:
            raise RuntimeError(
                "GitHub API rate limit reached. Set GITHUB_TOKEN for a higher limit."
            )
        if e.code == 422:
            raise RuntimeError(message)
        raise RuntimeError(f"GitHub API error {e.code}: {message}")
    except urllib.error.URLError as e:
        raise RuntimeError(f"Network error: {e.reason}")
    except Exception as e:
        raise RuntimeError(f"Request failed: {e}")

# ---------- Helpers ----------
def compact_num(n):
    try:
        n = int(n)
    except Exception:
        return "0"
    if n >= 1_000_000:
        return f"{n/1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n/1_000:.1f}k"
    return str(n)

def truncate(s, n=55):
    s = str(s or "").replace("\n", " ")
    return s if len(s) <= n else s[:n-1] + "…"

def score_user(query, user):
    """Extra local ranking on top of GitHub's search ranking."""
    q = query.lower()
    login = user.get("login", "").lower()
    score = 0
    if login == q:
        score += 1000
    if login.startswith(q):
        score += 300
    if q in login:
        score += 100
    score += min(int(user.get("followers", 0) or 0), 500)
    return score

def print_user(i, u):
    login = u.get("login", "?")
    typ = u.get("type", "User")
    score = u.get("_chrono_score", 0)
    print(
        f"{c(f'[{i:02}]', CYAN)} "
        f"{c(login, WHITE)} "
        f"{c(f'({typ})', GRAY)} "
        f"{c(f'score:{score}', MAGENTA)}"
    )

def print_repo(i, r):
    name = r.get("full_name", "?")
    stars = r.get("stargazers_count", 0)
    forks = r.get("forks_count", 0)
    lang = r.get("language") or "N/A"
    desc = truncate(r.get("description"), 58)
    print(
        f"{c(f'[{i:02}]', CYAN)} {c(name, WHITE)} "
        f"{c(f'★ {compact_num(stars)}', YELLOW)} "
        f"{c(f'⑂ {compact_num(forks)}', GRAY)} "
        f"{c(lang, GREEN)}"
    )
    if desc:
        print(f"     {c(desc, GRAY)}")

# ---------- User search ----------
def search_profiles():
    query = ask("\n[+] GitHub username/name to search: ")
    if not query:
        return

    try:
        spinner("Searching GitHub profiles")
        data = api_get("/search/users", {
            "q": query,
            "per_page": 30,
        })
        users = data.get("items", [])

        # Pull a little more profile information for better ranking.
        enriched = []
        for u in users[:15]:
            try:
                p = api_get("/users/" + urllib.parse.quote(u["login"]))
                u.update({
                    "followers": p.get("followers", 0),
                    "public_repos": p.get("public_repos", 0),
                })
            except Exception:
                u["followers"] = 0
                u["public_repos"] = 0
            u["_chrono_score"] = score_user(query, u)
            enriched.append(u)

        enriched.sort(
            key=lambda x: (
                x.get("_chrono_score", 0),
                x.get("followers", 0),
                x.get("public_repos", 0),
            ),
            reverse=True,
        )

        result_header("PROFILE SEARCH", query)
        if not enriched:
            print(c("No matching profiles found.", RED))
            return

        for i, u in enumerate(enriched, 1):
            print_user(i, u)

        choice = ask("\n[+] Enter result number to inspect (ENTER to return): ")
        if choice.isdigit() and 1 <= int(choice) <= len(enriched):
            show_profile(enriched[int(choice)-1]["login"])

    except RuntimeError as e:
        print(c(f"\n[!] {e}", RED))

def show_profile(login):
    try:
        p = api_get("/users/" + urllib.parse.quote(login))
    except RuntimeError as e:
        print(c(f"\n[!] {e}", RED))
        return

    clear()
    print(c("╔════════════════════════════════════════════════════════════╗", CYAN))
    print(c("║                     GITHUB PROFILE                       ║", CYAN))
    print(c("╚════════════════════════════════════════════════════════════╝", CYAN))
    print()
    print(f"{c('Username :', MAGENTA)} {c(p.get('login'), WHITE)}")
    print(f"{c('Name     :', MAGENTA)} {p.get('name') or 'N/A'}")
    print(f"{c('Type     :', MAGENTA)} {p.get('type') or 'User'}")
    print(f"{c('Bio      :', MAGENTA)} {truncate(p.get('bio'), 70) or 'N/A'}")
    print(f"{c('Location :', MAGENTA)} {p.get('location') or 'N/A'}")
    print(f"{c('Followers:', MAGENTA)} {compact_num(p.get('followers', 0))}")
    print(f"{c('Following:', MAGENTA)} {compact_num(p.get('following', 0))}")
    print(f"{c('Repos    :', MAGENTA)} {compact_num(p.get('public_repos', 0))}")
    print(f"{c('Gists    :', MAGENTA)} {compact_num(p.get('public_gists', 0))}")
    print(f"{c('Profile  :', MAGENTA)} {p.get('html_url')}")
    print()

    repos = api_get("/users/" + urllib.parse.quote(login) + "/repos", {
        "per_page": 10,
        "sort": "stars",
        "direction": "desc",
    })

    line()
    print(c("TOP PUBLIC REPOSITORIES", BOLD + YELLOW))
    line()
    for i, r in enumerate(repos[:10], 1):
        print_repo(i, r)

    action = ask("\n[O] Open profile  [R] View repo  [ENTER] Back: ").lower()
    if action == "o":
        open_url(p.get("html_url"))
    elif action == "r" and repos:
        num = ask("[+] Repo number: ")
        if num.isdigit() and 1 <= int(num) <= len(repos):
            show_repo(repos[int(num)-1]["full_name"])

# ---------- Repository / tool search ----------
def normalize_tool_query(query):
    aliases = {
        "osint": "OSINT",
        "rat": "remote access trojan",
        "scanner": "security scanner",
        "port scanner": "port scanner",
        "web scanner": "web vulnerability scanner",
        "subdomain": "subdomain enumeration",
        "directory scanner": "web content discovery",
        "phishing": "phishing simulation",
    }
    q = query.strip()
    return aliases.get(q.lower(), q)

def search_programs():
    query = ask("\n[+] Tool/program to search for: ")
    if not query:
        return

    q = normalize_tool_query(query)
    try:
        spinner("Searching GitHub projects")
        # GitHub's ranking already considers relevance. We then sort by
        # a popularity signal so highly-starred, active projects rise.
        data = api_get("/search/repositories", {
            "q": q + " in:name,description,readme",
            "sort": "stars",
            "order": "desc",
            "per_page": 30,
        })
        repos = data.get("items", [])

        # Filter obvious noise and archived projects unless the user asks for them.
        active = [r for r in repos if not r.get("archived", False)]
        if active:
            repos = active

        # Popularity score: stars dominate, then forks/watchers/recent activity.
        for r in repos:
            r["_chrono_pop"] = (
                int(r.get("stargazers_count", 0) or 0) * 10
                + int(r.get("forks_count", 0) or 0) * 3
                + int(r.get("watchers_count", 0) or 0)
            )
        repos.sort(key=lambda r: r["_chrono_pop"], reverse=True)

        result_header("PROGRAM / TOOL SEARCH", query)
        if not repos:
            print(c("No related repositories found.", RED))
            return

        for i, r in enumerate(repos[:20], 1):
            print_repo(i, r)

        choice = ask("\n[+] Enter result number to inspect (ENTER to return): ")
        if choice.isdigit() and 1 <= int(choice) <= min(20, len(repos)):
            show_repo(repos[int(choice)-1]["full_name"])

    except RuntimeError as e:
        print(c(f"\n[!] {e}", RED))

def show_repo(full_name):
    try:
        r = api_get("/repos/" + full_name)
    except RuntimeError as e:
        print(c(f"\n[!] {e}", RED))
        return

    clear()
    print(c("╔" + "═" * 66 + "╗", CYAN))
    print(c("║" + " PROGRAM DETAILS".ljust(66) + "║", WHITE + BOLD))
    print(c("╚" + "═" * 66 + "╝", CYAN))
    status_bar()
    print()
    print(f"{c('Project  :', MAGENTA)} {r.get('full_name')}")
    print(f"{c('Author   :', MAGENTA)} {r.get('owner', {}).get('login')}")
    print(f"{c('Stars    :', MAGENTA)} ★ {compact_num(r.get('stargazers_count', 0))}")
    print(f"{c('Forks    :', MAGENTA)} {compact_num(r.get('forks_count', 0))}")
    print(f"{c('Issues   :', MAGENTA)} {compact_num(r.get('open_issues_count', 0))}")
    print(f"{c('Language :', MAGENTA)} {r.get('language') or 'N/A'}")
    print(f"{c('License  :', MAGENTA)} {(r.get('license') or {}).get('spdx_id') or 'N/A'}")
    print(f"{c('Archived :', MAGENTA)} {'YES' if r.get('archived') else 'NO'}")
    print(f"{c('Updated  :', MAGENTA)} {r.get('updated_at', 'N/A')}")
    print(f"{c('Description:', MAGENTA)} {r.get('description') or 'N/A'}")
    print()
    print(c("URLs", BOLD + YELLOW))
    print(f"  Web    : {r.get('html_url')}")
    print(f"  Clone  : {r.get('clone_url')}")
    if r.get("homepage"):
        print(f"  Website: {r.get('homepage')}")

    print()
    action = ask("[O] Open  [C] Clone  [ENTER] Back: ").lower()

    if action == "o":
        open_url(r.get("html_url"))
    elif action == "c":
        if not shutil.which("git"):
            print(c("Git is not installed.", RED))
            return
        folder = Path.home() / "repo-scout" / r["name"]
        folder.parent.mkdir(parents=True, exist_ok=True)
        print(c(f"[*] Cloning into {folder} ...", CYAN))
        subprocess.run(["git", "clone", r["clone_url"], str(folder)], check=False)

# ---------- Extra features ----------
def compare_repos():
    a = ask("\n[+] First repo (owner/name): ")
    b = ask("[+] Second repo (owner/name): ")
    if not a or not b:
        return
    try:
        ra = api_get("/repos/" + a)
        rb = api_get("/repos/" + b)
        print()
        line()
        print(c("REPOSITORY COMPARISON", BOLD + MAGENTA))
        line()
        rows = [
            ("Stars", ra.get("stargazers_count",0), rb.get("stargazers_count",0)),
            ("Forks", ra.get("forks_count",0), rb.get("forks_count",0)),
            ("Issues", ra.get("open_issues_count",0), rb.get("open_issues_count",0)),
            ("Language", ra.get("language") or "N/A", rb.get("language") or "N/A"),
            ("Archived", ra.get("archived"), rb.get("archived")),
        ]
        print(f"{'Metric':<14} {a:<27} {b}")
        line()
        for metric, x, y in rows:
            print(f"{metric:<14} {str(x):<27} {y}")
    except RuntimeError as e:
        print(c(f"[!] {e}", RED))

def rate_limit():
    try:
        d = api_get("/rate_limit")
        core = d.get("resources", {}).get("core", {})
        print()
        print(c("GITHUB API STATUS", BOLD + MAGENTA))
        print(f"Limit     : {core.get('limit')}")
        print(f"Remaining : {core.get('remaining')}")
        print(f"Reset     : {time.ctime(core.get('reset', 0))}")
        print(f"Token     : {'configured' if TOKEN else 'not configured'}")
    except RuntimeError as e:
        print(c(f"[!] {e}", RED))

# ---------- Main menu ----------
def main():
    while True:
        banner()
        print(c("  [01]  PROFILE SEARCH", WHITE))
        print(c("  [02]  PROGRAM / TOOL SEARCH", WHITE))
        print(c("  [03]  REPOSITORY DETAILS", WHITE))
        print(c("  [04]  COMPARE REPOSITORIES", WHITE))
        print(c("  [05]  API / RATE LIMIT STATUS", WHITE))
        print(c("  [06]  OPEN GITHUB", WHITE))
        print(c("  [07]  ABOUT REPO SCOUT", WHITE))
        print(c("  [00]  EXIT", RED))
        line()

        choice = ask("[+] SELECT OPTION ➜ ")

        if choice == "1":
            search_profiles()
            pause()
        elif choice == "2":
            search_programs()
            pause()
        elif choice == "3":
            repo = ask("[+] Repository owner/name ➜ ")
            if repo:
                show_repo(repo)
            pause()
        elif choice == "4":
            compare_repos()
            pause()
        elif choice == "5":
            rate_limit()
            pause()
        elif choice == "6":
            open_url("https://github.com")
        elif choice == "7":
            clear()
            print(c("REPO SCOUT", BOLD + CYAN))
            print()
            print("A lightweight GitHub discovery utility designed for Termux.")
            print("It uses GitHub's public API and ranks results so you can")
            print("quickly find profiles, projects, and related tools.")
            print()
            print(c("Coded by Chrono • v1.0", MAGENTA))
            pause()
        elif choice in ("0", "00", "q", "quit", "exit"):
            clear()
            print(c("REPO SCOUT OFFLINE. 👋", CYAN))
            break
        else:
            print(c("[!] Invalid option.", RED))
            time.sleep(0.7)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n" + c("REPO SCOUT OFFLINE.", CYAN))
