# Repo Scout

**GitHub Discovery & Project Intelligence**

Repo Scout is a terminal-based GitHub discovery utility for finding developers, repositories, and related projects without leaving the command line.

The interface is designed for quick searching and inspection, with ranked results, repository statistics, browser integration, and optional GitHub API authentication.

> Coded by Chrono

## Features

- Profile and username search
- Ranked profile matches
- Program and tool discovery
- Popularity-based repository ranking
- Repository information dashboard
- Repository comparison
- Browser integration on Termux
- Repository cloning
- GitHub API rate-limit status
- Optional GitHub token support
- No third-party Python packages

## Interface

Repo Scout uses a compact terminal dashboard with:

- Startup animation
- Status indicator
- Search progress indicator
- Result headers
- Ranked result lists
- Repository detail screens
- Numbered navigation

## Requirements

- Python 3
- Internet connection
- Git for repository cloning
- GitHub account is optional

No external Python modules are required.

## Installation

### Termux

```bash
pkg update
pkg install python git
```

Place the project in a directory of your choice:

```bash
mkdir -p ~/repo-scout
cd ~/repo-scout
```

Then run:

```bash
chmod +x repo_scout.py
./repo_scout.py
```

Or:

```bash
python repo_scout.py
```

### Linux

```bash
python3 repo_scout.py
```

## GitHub API

Repo Scout can use GitHub's public API without authentication.

For heavier use, set a personal GitHub token in the environment:

```bash
export GITHUB_TOKEN="YOUR_TOKEN"
```

Then start Repo Scout:

```bash
python repo_scout.py
```

The token is read from the environment and is not written to a project file.

## Main Menu

```text
[01]  PROFILE SEARCH
[02]  PROGRAM / TOOL SEARCH
[03]  REPOSITORY DETAILS
[04]  COMPARE REPOSITORIES
[05]  API / RATE LIMIT STATUS
[06]  OPEN GITHUB
[07]  ABOUT REPO SCOUT
[00]  EXIT
```

## Search

Profile search accepts usernames or names and returns GitHub accounts ranked using username similarity and available profile activity.

Program search accepts a tool, project type, or technical concept and returns related GitHub repositories. Results are ordered using popularity signals such as stars, forks, watchers, and repository activity.

Popularity is only a discovery signal. A highly starred repository is not automatically safe, maintained, or suitable for a particular use.

## Repository Inspection

A repository detail view provides:

```text
Project
Author
Stars
Forks
Open issues
Language
License
Archive status
Last update
Description
Repository URL
Clone URL
Project website
```

From the detail view you can open the project or clone it locally.

Repositories cloned through Repo Scout are placed under:

```text
~/repo-scout/<repository-name>
```

## Termux Browser Support

If `termux-open` is available, Repo Scout can open GitHub pages directly through Android's default browser.

Install Termux:API if you want broader Termux integration:

```bash
pkg install termux-api
```

## Project Structure

```text
repo-scout/
├── repo_scout.py
├── install.sh
└── README.md
```

## Notes

Repo Scout uses GitHub's official public API.

Search results depend on GitHub's search index and API availability. Repository popularity should not be treated as a security or quality guarantee.

Before installing third-party software, review its source, dependencies, releases, license, and recent activity.

## License

Add the license you want to use before publishing the project.

---

**Repo Scout v1.0**  
**Coded by Chrono**
