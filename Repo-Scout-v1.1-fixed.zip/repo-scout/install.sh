#!/data/data/com.termux/files/usr/bin/bash
set -e

echo "[*] Installing Repo Scout..."

pkg install -y python git
chmod +x repo_scout.py

echo
echo "[+] Installation complete."
echo "[+] Run: ./repo_scout.py"
